__all__ = ['general', 'kaggle']

import oalvays.general
import oalvays.kaggle