from oalvays.kaggle.reduce_memory_usage import reduce_mem_usage_sd

__all__ = ['reduce_mem_usage_sd']

